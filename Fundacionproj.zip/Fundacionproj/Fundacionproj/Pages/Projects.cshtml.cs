using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fundacionproj.Pages
{
    public class ProjectsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
