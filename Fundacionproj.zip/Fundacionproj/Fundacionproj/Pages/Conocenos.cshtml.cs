using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fundacionproj.Pages
{
    public class ConocenosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
